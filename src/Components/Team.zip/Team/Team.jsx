import React, { useState } from "react";
import "./Team.css";
import Data from "./data.json";
import TechLogo from "../Home/Images/tech-team.png";

function Team() {
  const [domain, setdomain] = useState("techTeamMembers");

  const generateCard = () => {
    return Data[domain].map((member, index) => (
      <div
        className="one-member"
        style={member["role"] == "Lead" ? { margin: "10px 40%" } : {}}
      >
        <img src={member["photoUrl"]} alt="image" />
        <p>{member["name"]}</p>
        <p>{member["role"]}</p>
        <p>{member["branch"]}</p>
        <div className="one-member-social-media">
          <a href={member["instaid"]} target="_blank" rel="noreferrer">
            <i className="fa-brands fa-instagram"></i>
          </a>
          <a
            className="linkOfSocialMedia"
            href={member["linkedinid"]}
            target="_blank"
            rel="noreferrer"
          >
            <i className="fa-brands fa-linkedin"></i>
          </a>
        </div>
      </div>
    ));
  };

  return (
    <div className="Team">
      <h1>Meet Our Team</h1>
      <div className="team-nav">
        <div
          id="tech"
          onClick={() => {
            setdomain("techTeamMembers");
          }}
        >
          <img src={TechLogo} alt="" />
        </div>
        <div
          id="social"
          onClick={() => {
            setdomain("socialMediaMembers");
          }}
        >
          social media
        </div>
        <div id="tech"></div>
        <div id="tech"></div>
        <div id="tech"></div>
        <div id="tech"></div>
      </div>
      <div className="team-members-name">{generateCard()}</div>
    </div>
  );
}

export default Team;
